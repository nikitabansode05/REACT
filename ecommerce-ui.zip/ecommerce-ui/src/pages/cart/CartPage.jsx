const CartPage = () => {
  return (
    <div>
      <h1>Your Shopping Cart</h1>
      <p>Items you added to cart will appear here.</p>
    </div>
  );
};

export default CartPage;