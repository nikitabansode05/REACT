const ProductCatalogPage = () => {
  return (
    <div>
      <h1>Product Catalog</h1>
      <p>List of all products will appear here.</p>
    </div>
  );
};

export default ProductCatalogPage;