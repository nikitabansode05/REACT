const HomePage = () => {
  return (
    <div>
      <h1>Welcome to E-Commerce Store</h1>
      <p>Explore products and start shopping!</p>
    </div>
  );
};

export default HomePage;